"""
Tizimli trading uchun grafik skrinshot tahlilchisi (FastAPI + OpenCV ORB).

Ishga tushirish:
    pip install -r requirements.txt
    uvicorn main:app --host 0.0.0.0 --port 8000 --reload

Brauzerda oching: http://localhost:8000
Swagger hujjatlari: http://localhost:8000/docs

Eslatma: bu dastur vizual o'xshashlik (ORB feature matching) asosida ishlaydi.
U moliyaviy maslahat bermaydi va foyda kafolatlamaydi.
"""

from __future__ import annotations

import logging
import re
import threading
import uuid
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np
from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.concurrency import run_in_threadpool
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

# --------------------------------------------------------------------------- #
# SOZLAMALAR
# --------------------------------------------------------------------------- #
BASE_DIR = Path(__file__).resolve().parent
XOTIRA_PAPKASI = BASE_DIR / "grafiklar_xotirasi"
NATIJA_PAPKASI = BASE_DIR / "tahlil_natijalari"
FRONTEND_FAYL = BASE_DIR / "index.html"

RUXSAT_ETILGAN_KENGAYTMALAR = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
MAKS_FAYL_HAJMI = 10 * 1024 * 1024  # 10 MB
MAKS_TAHLIL_OLCHAMI = 1000  # tahlil uchun uzun tomon (piksel)

ORB_NFEATURES = 3000
LOWE_RATIO = 0.75  # knnMatch uchun Lowe nisbati
MIN_GOOD_MATCHES = 15  # shundan kam bo'lsa - struktura mos emas hisoblanadi
MIN_RANSAC_INLIERS = 8  # gomografiya uchun minimal inlier soni

ALPHA = 0.3  # overlay shaffofligi
TP_RANGI = (0, 200, 0)  # BGR: yashil
SL_RANGI = (0, 0, 220)  # BGR: qizil
SL_NISBATI = 0.5  # SL balandligi = TP balandligining 50% (risk/reward 1:2)

FAYL_NOMI_PATTERN = re.compile(r"^[A-Za-z0-9_\-]+\.(png|jpg|jpeg|webp|bmp)$")

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)
log = logging.getLogger("trading_ai")


# --------------------------------------------------------------------------- #
# MA'LUMOT TUZILMALARI
# --------------------------------------------------------------------------- #
@dataclass
class Andoza:
    """Xotiradagi bitta ideal grafik andozasi."""

    nom: str
    yol: Path
    keypoints: List[cv2.KeyPoint]
    descriptors: np.ndarray
    olcham: Tuple[int, int]  # (kenglik, balandlik) - tahlil o'lchamida
    roi: Tuple[int, int, int, int]  # (x0, y0, x1, y1) grafik hududi
    kirish_y: int  # oxirgi shamlar joylashgan taxminiy narx chizig'i


@dataclass
class Moslik:
    andoza: Andoza
    good_matches: List[cv2.DMatch]
    gomografiya: Optional[np.ndarray] = None
    inliers: int = 0


@dataclass
class XotiraOmbori:
    andozalar: Dict[str, Andoza] = field(default_factory=dict)
    qulf: threading.Lock = field(default_factory=threading.Lock)


xotira = XotiraOmbori()


# --------------------------------------------------------------------------- #
# PYDANTIC MODELLAR
# --------------------------------------------------------------------------- #
class TahlilJavobi(BaseModel):
    muvaffaqiyat: bool
    mos_keldi: bool
    xabar: str
    rasm_nomi: str
    yuklab_olish_url: str
    mos_andoza: Optional[str] = None
    good_matches: int = 0
    ransac_inliers: int = 0
    ishonch_foizi: float = 0.0


class XotiraJavobi(BaseModel):
    muvaffaqiyat: bool
    xabar: str
    andoza_nomi: Optional[str] = None
    jami_andozalar: int = 0


class XotiraRoyxati(BaseModel):
    jami: int
    andozalar: List[str]


# --------------------------------------------------------------------------- #
# RASM BILAN ISHLASH YORDAMCHI FUNKSIYALARI
# --------------------------------------------------------------------------- #
def papkalarni_yaratish() -> None:
    """Dastur ishga tushganda ikkala papkani avtomatik ochadi."""
    for papka in (XOTIRA_PAPKASI, NATIJA_PAPKASI):
        papka.mkdir(parents=True, exist_ok=True)
        log.info("Papka tayyor: %s", papka)


def baytdan_rasm(data: bytes) -> np.ndarray:
    """Baytlardan BGR rasmni dekodlaydi."""
    arr = np.frombuffer(data, dtype=np.uint8)
    rasm = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if rasm is None:
        raise ValueError("Fayl yaroqli rasm emas yoki buzilgan.")
    return rasm


def olchamni_kamaytirish(rasm: np.ndarray, maks: int = MAKS_TAHLIL_OLCHAMI) -> np.ndarray:
    """Uzun tomonni `maks` pikselgacha proporsional kichraytiradi."""
    h, w = rasm.shape[:2]
    uzun = max(h, w)
    if uzun <= maks:
        return rasm
    masshtab = maks / float(uzun)
    return cv2.resize(rasm, (int(w * masshtab), int(h * masshtab)), interpolation=cv2.INTER_AREA)


def oldindan_ishlov(rasm: np.ndarray) -> np.ndarray:
    """Kulrang rang + CLAHE (kontrastni tenglash) - ORB uchun barqaror kirish."""
    kulrang = cv2.cvtColor(rasm, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    kulrang = clahe.apply(kulrang)
    return cv2.GaussianBlur(kulrang, (3, 3), 0)


def orb_xususiyatlari(rasm: np.ndarray) -> Tuple[List[cv2.KeyPoint], Optional[np.ndarray]]:
    """ORB detektori bilan burilish nuqtalari va shamlar geometriyasini ajratadi."""
    orb = cv2.ORB_create(
        nfeatures=ORB_NFEATURES,
        scaleFactor=1.2,
        nlevels=8,
        edgeThreshold=15,
        patchSize=31,
        fastThreshold=10,
    )
    kulrang = oldindan_ishlov(rasm)
    keypoints, descriptors = orb.detectAndCompute(kulrang, None)
    return list(keypoints or []), descriptors


def grafik_hududini_topish(rasm: np.ndarray) -> Tuple[Tuple[int, int, int, int], int]:
    """
    Grafik (shamlar) joylashgan hududni va oxirgi shamlar turgan narx chizig'ini
    (kirish_y) chekka (edge) zichligi orqali topadi.
    """
    h, w = rasm.shape[:2]
    kulrang = cv2.cvtColor(rasm, cv2.COLOR_BGR2GRAY)
    chekkalar = cv2.Canny(kulrang, 60, 160)

    ustun_zichligi = chekkalar.sum(axis=0).astype(np.float64)
    qator_zichligi = chekkalar.sum(axis=1).astype(np.float64)

    def chegara(zichlik: np.ndarray, ulush: float) -> Tuple[int, int]:
        if zichlik.max() <= 0:
            return 0, len(zichlik) - 1
        faol = np.where(zichlik >= zichlik.max() * ulush)[0]
        if faol.size == 0:
            return 0, len(zichlik) - 1
        return int(faol[0]), int(faol[-1])

    x0, x1 = chegara(ustun_zichligi, 0.05)
    y0, y1 = chegara(qator_zichligi, 0.05)

    # Juda tor hudud chiqsa - butun rasmni (kichik chetlar bilan) olamiz
    if (x1 - x0) < w * 0.3 or (y1 - y0) < h * 0.3:
        x0, y0, x1, y1 = int(w * 0.02), int(h * 0.05), int(w * 0.98), int(h * 0.95)

    # Oxirgi shamlar: hududning o'ng 12% qismidagi chekkalarning o'rtacha Y koordinatasi
    o_ng_boshi = max(x0, x1 - int((x1 - x0) * 0.12))
    qism = chekkalar[y0 : y1 + 1, o_ng_boshi : x1 + 1]
    ys, _ = np.nonzero(qism)
    if ys.size >= 5:
        kirish_y = int(np.median(ys)) + y0
    else:
        kirish_y = (y0 + y1) // 2

    kirish_y = int(np.clip(kirish_y, y0 + (y1 - y0) * 0.2, y1 - (y1 - y0) * 0.2))
    return (x0, y0, x1, y1), kirish_y


def andoza_yuklash(yol: Path) -> Optional[Andoza]:
    """Fayldan bitta andozani o'qib, ORB deskriptorlarini hisoblaydi."""
    try:
        rasm = olchamni_kamaytirish(baytdan_rasm(yol.read_bytes()))
    except Exception as xato:  # noqa: BLE001
        log.warning("Andoza o'qilmadi (%s): %s", yol.name, xato)
        return None

    keypoints, descriptors = orb_xususiyatlari(rasm)
    if descriptors is None or len(keypoints) < 10:
        log.warning("Andozada xususiyat yetarli emas: %s", yol.name)
        return None

    h, w = rasm.shape[:2]
    roi, kirish_y = grafik_hududini_topish(rasm)
    return Andoza(
        nom=yol.name,
        yol=yol,
        keypoints=keypoints,
        descriptors=descriptors,
        olcham=(w, h),
        roi=roi,
        kirish_y=kirish_y,
    )


def xotirani_yuklash() -> int:
    """Papkadagi barcha andozalarni xotira keshiga yuklaydi."""
    yangi: Dict[str, Andoza] = {}
    for yol in sorted(XOTIRA_PAPKASI.iterdir()):
        if yol.is_file() and yol.suffix.lower() in RUXSAT_ETILGAN_KENGAYTMALAR:
            andoza = andoza_yuklash(yol)
            if andoza is not None:
                yangi[andoza.nom] = andoza
    with xotira.qulf:
        xotira.andozalar = yangi
    log.info("Xotiraga yuklangan andozalar soni: %d", len(yangi))
    return len(yangi)


# --------------------------------------------------------------------------- #
# ORB MATCHING
# --------------------------------------------------------------------------- #
def andoza_bilan_solishtirish(
    yangi_kp: List[cv2.KeyPoint], yangi_des: np.ndarray, andoza: Andoza
) -> Moslik:
    """Bitta andoza bilan Hamming + Lowe ratio test orqali solishtiradi."""
    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
    try:
        juftliklar = bf.knnMatch(andoza.descriptors, yangi_des, k=2)
    except cv2.error:
        return Moslik(andoza=andoza, good_matches=[])

    good: List[cv2.DMatch] = []
    for juft in juftliklar:
        if len(juft) == 2 and juft[0].distance < LOWE_RATIO * juft[1].distance:
            good.append(juft[0])

    moslik = Moslik(andoza=andoza, good_matches=good)

    # Geometrik tasdiqlash: RANSAC gomografiya
    if len(good) >= 4:
        src = np.float32([andoza.keypoints[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
        dst = np.float32([yangi_kp[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
        H, maska = cv2.findHomography(src, dst, cv2.RANSAC, 5.0)
        if H is not None and maska is not None:
            moslik.gomografiya = H
            moslik.inliers = int(maska.sum())
    return moslik


def eng_yaxshi_andozani_topish(yangi: np.ndarray) -> Tuple[Optional[Moslik], int]:
    """Barcha andozalar orasidan eng ko'p Good Matches topilganini qaytaradi."""
    yangi_kp, yangi_des = orb_xususiyatlari(yangi)
    if yangi_des is None or len(yangi_kp) < 10:
        return None, len(yangi_kp)

    with xotira.qulf:
        andozalar = list(xotira.andozalar.values())

    eng_yaxshi: Optional[Moslik] = None
    for andoza in andozalar:
        moslik = andoza_bilan_solishtirish(yangi_kp, yangi_des, andoza)
        log.info(
            "Andoza '%s': good=%d inliers=%d",
            andoza.nom,
            len(moslik.good_matches),
            moslik.inliers,
        )
        if eng_yaxshi is None or len(moslik.good_matches) > len(eng_yaxshi.good_matches):
            eng_yaxshi = moslik
    return eng_yaxshi, len(yangi_kp)


# --------------------------------------------------------------------------- #
# ZONALARNI HISOBLASH VA CHIZISH
# --------------------------------------------------------------------------- #
Zona = Tuple[int, int, int, int]  # x0, y0, x1, y1


def andoza_zonalari(andoza: Andoza) -> Tuple[np.ndarray, np.ndarray]:
    """
    Andoza geometriyasidan TP va SL to'rtburchaklarini (4 burchak nuqtasi) hisoblaydi.
    TP - kirish chizig'idan yuqorida, SL - pastda. Zonalar grafikning o'ng qismida
    (kelajak harakat hududi) joylashadi.
    """
    x0, y0, x1, y1 = andoza.roi
    kenglik = x1 - x0
    zona_x0 = x0 + int(kenglik * 0.60)
    zona_x1 = x1
    bo_shliq = max(2, int((y1 - y0) * 0.01))

    tp_y0 = y0
    tp_y1 = andoza.kirish_y - bo_shliq
    tp_balandlik = max(tp_y1 - tp_y0, 1)

    sl_y0 = andoza.kirish_y + bo_shliq
    sl_y1 = min(y1, sl_y0 + int(tp_balandlik * SL_NISBATI))

    tp = np.float32([[zona_x0, tp_y0], [zona_x1, tp_y0], [zona_x1, tp_y1], [zona_x0, tp_y1]])
    sl = np.float32([[zona_x0, sl_y0], [zona_x1, sl_y0], [zona_x1, sl_y1], [zona_x0, sl_y1]])
    return tp.reshape(-1, 1, 2), sl.reshape(-1, 1, 2)


def burchaklardan_zona(burchaklar: np.ndarray, kenglik: int, balandlik: int) -> Zona:
    """Burchak nuqtalaridan rasm ichida qoladigan to'g'ri to'rtburchak hosil qiladi."""
    pts = burchaklar.reshape(-1, 2)
    x0 = int(np.clip(pts[:, 0].min(), 0, kenglik - 1))
    x1 = int(np.clip(pts[:, 0].max(), 0, kenglik - 1))
    y0 = int(np.clip(pts[:, 1].min(), 0, balandlik - 1))
    y1 = int(np.clip(pts[:, 1].max(), 0, balandlik - 1))
    return x0, y0, x1, y1


def gomografiya_yaroqlimi(H: np.ndarray, inliers: int) -> bool:
    """Gomografiya juda buzilgan yoki ishonchsiz bo'lsa, rad etadi."""
    if H is None or inliers < MIN_RANSAC_INLIERS:
        return False
    # Perspektiva komponentlari va masshtab oqilona oraliqda bo'lishi kerak
    if abs(H[2, 0]) > 0.005 or abs(H[2, 1]) > 0.005:
        return False
    det = np.linalg.det(H[:2, :2])
    return 0.15 < det < 6.0


def zonalarni_aniqlash(moslik: Moslik, yangi: np.ndarray) -> Tuple[Zona, Zona]:
    """Yangi rasm uchun TP va SL zonalarini aniqlaydi."""
    h, w = yangi.shape[:2]
    tp_burchak, sl_burchak = andoza_zonalari(moslik.andoza)

    if moslik.gomografiya is not None and gomografiya_yaroqlimi(moslik.gomografiya, moslik.inliers):
        tp_yangi = cv2.perspectiveTransform(tp_burchak, moslik.gomografiya)
        sl_yangi = cv2.perspectiveTransform(sl_burchak, moslik.gomografiya)
        tp_zona = burchaklardan_zona(tp_yangi, w, h)
        sl_zona = burchaklardan_zona(sl_yangi, w, h)
    else:
        # Zaxira variant: andoza nisbatlarini yangi rasm o'lchamiga ko'chiramiz
        aw, ah = moslik.andoza.olcham
        sx, sy = w / float(aw), h / float(ah)
        shkala = np.float32([[sx, 0, 0], [0, sy, 0], [0, 0, 1]])
        tp_zona = burchaklardan_zona(cv2.perspectiveTransform(tp_burchak, shkala), w, h)
        sl_zona = burchaklardan_zona(cv2.perspectiveTransform(sl_burchak, shkala), w, h)

    # Zonalar bir-birini kesib o'tmasligi uchun TP pastki chegarasi SL yuqorisidan oshmasin
    if tp_zona[3] > sl_zona[1]:
        o_rta = (tp_zona[3] + sl_zona[1]) // 2
        tp_zona = (tp_zona[0], tp_zona[1], tp_zona[2], max(tp_zona[1] + 1, o_rta - 1))
        sl_zona = (sl_zona[0], min(sl_zona[3] - 1, o_rta + 1), sl_zona[2], sl_zona[3])
    return tp_zona, sl_zona


def matn_yozish(rasm: np.ndarray, matn: str, zona: Zona, rang: Tuple[int, int, int]) -> None:
    """Zona ichiga o'qiladigan (orqa fonli) yozuv yozadi."""
    x0, y0, x1, y1 = zona
    shrift = cv2.FONT_HERSHEY_SIMPLEX
    kenglik = max(x1 - x0, 1)

    masshtab = max(0.4, min(1.0, kenglik / 380.0))
    qalinlik = 2 if masshtab >= 0.6 else 1
    (tw, th), asos = cv2.getTextSize(matn, shrift, masshtab, qalinlik)

    # Matn zonaga sig'masa - kichraytiramiz
    while tw > kenglik - 12 and masshtab > 0.3:
        masshtab -= 0.05
        (tw, th), asos = cv2.getTextSize(matn, shrift, masshtab, qalinlik)

    tx = x0 + max(6, (kenglik - tw) // 2)
    ty = y0 + th + 10
    if ty > y1:
        return

    cv2.rectangle(rasm, (tx - 5, ty - th - 5), (tx + tw + 5, ty + asos + 3), (255, 255, 255), -1)
    cv2.rectangle(rasm, (tx - 5, ty - th - 5), (tx + tw + 5, ty + asos + 3), rang, 1)
    cv2.putText(rasm, matn, (tx, ty), shrift, masshtab, rang, qalinlik, cv2.LINE_AA)


def zonalarni_chizish(rasm: np.ndarray, tp: Zona, sl: Zona) -> np.ndarray:
    """cv2.addWeighted (alpha=0.3) bilan shaffof TP/SL zonalarini chizadi."""
    qatlam = rasm.copy()
    cv2.rectangle(qatlam, (tp[0], tp[1]), (tp[2], tp[3]), TP_RANGI, thickness=-1)
    cv2.rectangle(qatlam, (sl[0], sl[1]), (sl[2], sl[3]), SL_RANGI, thickness=-1)
    natija = cv2.addWeighted(qatlam, ALPHA, rasm, 1.0 - ALPHA, 0)

    # Chegara chiziqlari va yozuvlar (aniq ko'rinishi uchun)
    cv2.rectangle(natija, (tp[0], tp[1]), (tp[2], tp[3]), TP_RANGI, 2)
    cv2.rectangle(natija, (sl[0], sl[1]), (sl[2], sl[3]), SL_RANGI, 2)
    matn_yozish(natija, "AI TAKE PROFIT ZONE", tp, (0, 140, 0))
    matn_yozish(natija, "AI STOP LOSS ZONE", sl, (0, 0, 190))
    return natija


def ishonch_foizi(moslik: Moslik) -> float:
    """Good matches va RANSAC inlier'lariga asoslangan taxminiy ishonch (0-100)."""
    asos = min(len(moslik.good_matches) / 80.0, 1.0)
    inlier = min(moslik.inliers / 40.0, 1.0)
    return round((0.4 * asos + 0.6 * inlier) * 100.0, 1)


# --------------------------------------------------------------------------- #
# ASOSIY TAHLIL JARAYONI (CPU-og'ir, threadpool'da ishlaydi)
# --------------------------------------------------------------------------- #
def tahlilni_bajarish(data: bytes) -> Tuple[np.ndarray, Optional[Moslik], bool]:
    asl = baytdan_rasm(data)
    ish_rasmi = olchamni_kamaytirish(asl)

    with xotira.qulf:
        bo_sh = len(xotira.andozalar) == 0
    if bo_sh:
        return ish_rasmi, None, False

    moslik, _ = eng_yaxshi_andozani_topish(ish_rasmi)
    if moslik is None or len(moslik.good_matches) < MIN_GOOD_MATCHES:
        return ish_rasmi, moslik, False

    tp_zona, sl_zona = zonalarni_aniqlash(moslik, ish_rasmi)
    natija = zonalarni_chizish(ish_rasmi, tp_zona, sl_zona)
    return natija, moslik, True


def faylni_xavfsiz_saqlash(papka: Path, nom_asosi: str, kengaytma: str, rasm: np.ndarray) -> str:
    kengaytma = kengaytma if kengaytma in RUXSAT_ETILGAN_KENGAYTMALAR else ".png"
    fayl_nomi = f"{nom_asosi}{kengaytma}"
    muvaffaqiyat, buf = cv2.imencode(kengaytma, rasm)
    if not muvaffaqiyat:
        raise RuntimeError("Rasmni kodlab bo'lmadi.")
    (papka / fayl_nomi).write_bytes(buf.tobytes())
    return fayl_nomi


async def yuklanganni_oqish(fayl: UploadFile) -> Tuple[bytes, str]:
    """Yuklangan faylni tekshiradi (kengaytma, hajm) va baytlarini qaytaradi."""
    kengaytma = Path(fayl.filename or "").suffix.lower()
    if kengaytma not in RUXSAT_ETILGAN_KENGAYTMALAR:
        raise HTTPException(
            status_code=415,
            detail=f"Qo'llab-quvvatlanmaydigan format. Ruxsat etilgan: {', '.join(sorted(RUXSAT_ETILGAN_KENGAYTMALAR))}",
        )
    data = await fayl.read(MAKS_FAYL_HAJMI + 1)
    if len(data) == 0:
        raise HTTPException(status_code=400, detail="Fayl bo'sh.")
    if len(data) > MAKS_FAYL_HAJMI:
        raise HTTPException(
            status_code=413, detail=f"Fayl hajmi {MAKS_FAYL_HAJMI // (1024 * 1024)} MB dan oshmasligi kerak."
        )
    return data, kengaytma


# --------------------------------------------------------------------------- #
# FASTAPI ILOVASI
# --------------------------------------------------------------------------- #
@asynccontextmanager
async def lifespan(_: FastAPI):
    papkalarni_yaratish()
    await run_in_threadpool(xotirani_yuklash)
    yield
    log.info("Dastur to'xtatildi.")


app = FastAPI(
    title="Trading Grafik Tahlilchisi (ORB)",
    description="Foydalanuvchi yuklagan grafik skrinshotlarini xotiradagi andozalar bilan solishtirib, TP/SL zonalarini chizadi.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/", include_in_schema=False)
async def bosh_sahifa():
    if FRONTEND_FAYL.exists():
        return FileResponse(FRONTEND_FAYL, media_type="text/html")
    return {"xabar": "API ishlayapti. Hujjatlar: /docs"}


@app.post("/tahlil-va-tp-zonasi/", response_model=TahlilJavobi)
async def tahlil_va_tp_zonasi(request: Request, file: UploadFile = File(...)):
    """Rasmni tahlil qiladi, TP/SL zonalarini chizadi va natijani saqlaydi."""
    data, kengaytma = await yuklanganni_oqish(file)

    try:
        natija, moslik, mos = await run_in_threadpool(tahlilni_bajarish, data)
    except ValueError as xato:
        raise HTTPException(status_code=400, detail=str(xato))
    except Exception:  # noqa: BLE001
        log.exception("Tahlil jarayonida kutilmagan xato")
        raise HTTPException(status_code=500, detail="Tahlil paytida ichki xato yuz berdi.")

    vaqt = datetime.now().strftime("%Y%m%d_%H%M%S")
    nom_asosi = f"{'tahlil' if mos else 'mos_emas'}_{vaqt}_{uuid.uuid4().hex[:8]}"
    fayl_nomi = await run_in_threadpool(
        faylni_xavfsiz_saqlash, NATIJA_PAPKASI, nom_asosi, kengaytma, natija
    )
    url = str(request.url_for("yuklab_olish", fayl_nomi=fayl_nomi))

    if moslik is None and not mos:
        xabar = "Xotira bo'sh yoki rasmda yetarli xususiyat topilmadi. Avval /xotiraga-qoshish/ orqali andoza qo'shing."
    elif not mos:
        xabar = (
            f"Trend strukturasi mos kelmadi (good matches: {len(moslik.good_matches)}, "
            f"kerak: {MIN_GOOD_MATCHES}). Zona chizilmadi."
        )
    else:
        xabar = f"Struktura '{moslik.andoza.nom}' andozasiga mos keldi. TP/SL zonalari chizildi."

    return TahlilJavobi(
        muvaffaqiyat=True,
        mos_keldi=mos,
        xabar=xabar,
        rasm_nomi=fayl_nomi,
        yuklab_olish_url=url,
        mos_andoza=moslik.andoza.nom if (moslik and mos) else None,
        good_matches=len(moslik.good_matches) if moslik else 0,
        ransac_inliers=moslik.inliers if moslik else 0,
        ishonch_foizi=ishonch_foizi(moslik) if (moslik and mos) else 0.0,
    )


@app.get("/yuklab-olish/{fayl_nomi}", name="yuklab_olish")
async def yuklab_olish(fayl_nomi: str):
    """Ishlov berilgan tayyor rasmni qaytaradi."""
    if not FAYL_NOMI_PATTERN.match(fayl_nomi):
        raise HTTPException(status_code=400, detail="Fayl nomi yaroqsiz.")
    yol = (NATIJA_PAPKASI / fayl_nomi).resolve()
    if NATIJA_PAPKASI.resolve() not in yol.parents or not yol.is_file():
        raise HTTPException(status_code=404, detail="Fayl topilmadi.")
    return FileResponse(yol, filename=fayl_nomi)


# --------------------------------------------------------------------------- #
# QO'SHIMCHA: XOTIRANI BOSHQARISH (andozalarni qo'shish uchun)
# --------------------------------------------------------------------------- #
@app.post("/xotiraga-qoshish/", response_model=XotiraJavobi)
async def xotiraga_qoshish(file: UploadFile = File(...)):
    """Foyda keltirgan ideal grafik andozasini 'grafiklar_xotirasi' ga qo'shadi."""
    data, kengaytma = await yuklanganni_oqish(file)
    try:
        await run_in_threadpool(baytdan_rasm, data)
    except ValueError as xato:
        raise HTTPException(status_code=400, detail=str(xato))

    asl_nom = re.sub(r"[^A-Za-z0-9_\-]", "_", Path(file.filename or "andoza").stem)[:40] or "andoza"
    fayl_nomi = f"{asl_nom}_{uuid.uuid4().hex[:6]}{kengaytma}"
    yol = XOTIRA_PAPKASI / fayl_nomi
    yol.write_bytes(data)

    andoza = await run_in_threadpool(andoza_yuklash, yol)
    if andoza is None:
        yol.unlink(missing_ok=True)
        raise HTTPException(
            status_code=422,
            detail="Rasmda yetarli xususiyat (burilish nuqtalari) topilmadi. Aniqroq grafik yuklang.",
        )
    with xotira.qulf:
        xotira.andozalar[andoza.nom] = andoza
        jami = len(xotira.andozalar)
    return XotiraJavobi(muvaffaqiyat=True, xabar="Andoza xotiraga qo'shildi.", andoza_nomi=andoza.nom, jami_andozalar=jami)


@app.get("/xotira/", response_model=XotiraRoyxati)
async def xotira_royxati():
    with xotira.qulf:
        nomlar = sorted(xotira.andozalar.keys())
    return XotiraRoyxati(jami=len(nomlar), andozalar=nomlar)


@app.post("/xotirani-yangilash/", response_model=XotiraJavobi)
async def xotirani_yangilash():
    """Papkaga qo'lda tashlangan andozalarni qayta yuklaydi."""
    jami = await run_in_threadpool(xotirani_yuklash)
    return XotiraJavobi(muvaffaqiyat=True, xabar="Xotira qayta yuklandi.", jami_andozalar=jami)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
